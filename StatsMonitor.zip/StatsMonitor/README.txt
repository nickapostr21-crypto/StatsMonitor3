Stats Monitor widget (no launcher icon).
Upload StatsMonitor.zip to the GitHub repo (same name replaces the old one); the Actions tab builds app-debug.apk.
